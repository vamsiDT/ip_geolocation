# -*- coding: utf-8 -*-
# pylint: disable=missing-docstring

if __name__ == '__main__':
    from ip2geotools.cli import execute_from_command_line
    execute_from_command_line()
